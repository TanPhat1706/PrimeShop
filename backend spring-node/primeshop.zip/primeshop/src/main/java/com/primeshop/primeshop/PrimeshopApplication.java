package com.primeshop.primeshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimeshopApplication.class, args);
	}

}
